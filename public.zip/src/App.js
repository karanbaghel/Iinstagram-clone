import React from 'react'
import App4 from './App4'
import Gauti from './Gauti'
import Karan from './Karan'
import Karan2 from './Karan2'
import Story from './Story'
import Highlight from './Highlight'

const App = () => {
  return (
    <>
    {/* <App4/> */}
    {/* <Gauti/> */}

    {/* <Karan/>/ */}
<Karan2/>
{/* <Story/> */}
{/* <Highlight/> */}
    </>
  )
}

export default App